MapReduce: Simplified Data Processing on Large Clusters   
###[MapReduce Original English Version](http://static.googleusercontent.com/media/research.google.com/en//archive/mapreduce-osdi04.pdf)   
###[MapReduce 翻译版](http://www.cnblogs.com/fuzhe1989/p/3413457.html)
