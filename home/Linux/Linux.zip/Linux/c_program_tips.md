1 How to allocate aligned memory only using the standard library?
[URL](http://stackoverflow.com/questions/227897/how-to-allocate-aligned-memory-only-using-the-standard-library)
